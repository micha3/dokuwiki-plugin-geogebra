<?php
/**
 * Plugin Geogebra: Sets new colors for text and background.
 * 
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Christopher Smith <chris@jalakai.co.uk>
 */
 
// must be run within DokuWiki
if(!defined('DOKU_INC')) die();
 
if(!defined('DOKU_PLUGIN')) define('DOKU_PLUGIN',DOKU_INC.'lib/plugins/');
require_once(DOKU_PLUGIN.'syntax.php');
 
/**
 * All DokuWiki plugins to extend the parser/rendering mechanism
 * need to inherit from this class
 */
class syntax_plugin_ggb extends DokuWiki_Syntax_Plugin {
 
    function getType(){ return 'formatting'; }
    function getAllowedTypes() { return array('formatting', 'substition', 'disabled'); }   
    function getSort(){ return 158; }
    function connectTo($mode) { $this->Lexer->addEntryPattern('<ggb.*?>(?=.*?</ggb>)',$mode,'plugin_ggb'); }
    function postConnect() { $this->Lexer->addExitPattern('</ggb>','plugin_ggb'); }
 
 
    /**
     * Handle the match
     */
    function handle($match, $state, $pos, Doku_Handler $handler){
        switch ($state) {
          case DOKU_LEXER_ENTER :
	    list($strheight) = preg_split("/\//u", substr($match, 4, -1), 1);
            $height = intval($strheight);
	    if (($height<100)||($height>480)) $height=480;
		return array($state, $height);
 
          case DOKU_LEXER_UNMATCHED :
	    return array($state, $match);
          case DOKU_LEXER_EXIT :
	    return array($state, '');
        }
        return array();
    }
 
    /**
     * Create output
     */
    function render($mode, Doku_Renderer $renderer, $data) {
        if($mode == 'xhtml'){
            list($state, $match) = $data;
            switch ($state) {
              case DOKU_LEXER_ENTER :      
                //list($color, $background) = $match;
                $renderer->doc .= "    <script type=\"text/javascript\" src=\"https://www.geogebra.org/web/5.0/web/web.nocache.js\"></script>
    <h1>Sinus und Kosinus am Einheitskreis<h1>
    <article class=\"geogebraweb\"
             id=\"applet1\"
             data-param-id=\"applet1\"
             data-param-showMenubar=\"false\"
             data-param-showToolbar=\"false\"
             data-param-showAlgebraInput=\"false\"
             data-param-showResetIcon=\"true\"
             data-param-width=\"640\"
             data-param-height=\"$match\"
             data-param-language=\"de\"
             data-param-ggbbase64=\""; 
                break;
 
              case DOKU_LEXER_UNMATCHED :
		//$datei = "/var/www/html/dokuwiki2/data/media/".$match;
		$datei = "./data/media/".$match;
		$inhalt = file_get_contents($datei);
	        //$renderer->doc .= $renderer->_xmlEntities($match);
		$renderer->doc .= wordwrap(base64_encode($inhalt), 40)."\"></article>\n";
		break;
              case DOKU_LEXER_EXIT :       $renderer->doc .= "";
		break;
            }
            return true;
        }
        return false;
    }
}
?>
